seqfile = /scratch/project_2004342/everything/paml_clean/FINAL_refseq_ftp_pipeline/11_paml_nuclear_final/alignments/CPT1A.phy
treefile = /scratch/project_2004342/everything/paml_clean/FINAL_refseq_ftp_pipeline/11_paml_nuclear_final/trees/site/CPT1A/CPT1A.pruned.unlabelled.tree
outfile = /scratch/project_2004342/everything/paml_clean/FINAL_refseq_ftp_pipeline/11_paml_nuclear_final/results/CPT1A/site_models/M0/CPT1A.M0.out

noisy = 0
verbose = 1
runmode = 0

seqtype = 1
CodonFreq = 2
clock = 0
aaDist = 0

model = 0
NSsites = 0

icode = 0
Mgene = 0

fix_kappa = 0
kappa = 2

fix_omega = 0
omega = 0.4

fix_alpha = 1
alpha = 0
Malpha = 0
ncatG = 4

getSE = 0
RateAncestor = 0
Small_Diff = 0.5e-6
cleandata = 1
method = 0
