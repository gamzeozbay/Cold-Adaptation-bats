seqfile = /scratch/project_2004342/everything/paml_clean/FINAL_refseq_ftp_pipeline/11_paml_nuclear_final/alignments/CPT2.phy
treefile = /scratch/project_2004342/everything/paml_clean/FINAL_refseq_ftp_pipeline/11_paml_nuclear_final/trees/labelled/CPT2/myotis_cold_wholeclade/CPT2.myotis_cold_wholeclade.labelled.tree
outfile = /scratch/project_2004342/everything/paml_clean/FINAL_refseq_ftp_pipeline/11_paml_nuclear_final/results/CPT2/branchsite/myotis_cold_wholeclade/BS_alt/CPT2.myotis_cold_wholeclade.BS_alt.out

noisy = 0
verbose = 1
runmode = 0

seqtype = 1
CodonFreq = 2
clock = 0
aaDist = 0

model = 2
NSsites = 2

icode = 0
Mgene = 0

fix_kappa = 0
kappa = 2

fix_omega = 0
omega = 1.5

fix_alpha = 1
alpha = 0
Malpha = 0
ncatG = 4

getSE = 0
RateAncestor = 0
Small_Diff = 0.5e-6
cleandata = 1
method = 0
